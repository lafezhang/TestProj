//
//  PostBuildAction.h
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/10.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PostBuildAction : NSObject

- (id)initWithMetaToolPath:(NSString*)metaToolPath outputFile:(NSString*)outputFile;
- (void)doAction;
@end
