//
//  main.m
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/10.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GBCli.h"
#import "PostBuildAction.h"
#import "BuildEnvoriment.h"
#import "MetaBuildSettings.h"
const NSString* version = @
#include "version.d"
;
//static float version = #import "version";

void registerOptions(GBOptionsHelper *options) {
    
    [options registerSeparator:@"COMMANDS:"];
    [options registerOption:'m' long:@"meta" description:@"meta tool exe path" flags:GBOptionOptionalValue];
    [options registerOption:'v' long:@"ver" description:@"verstion " flags:GBOptionNoValue];
    [options registerOption:'c' long:@"clean" description:@"clean " flags:GBOptionNoValue];
    [options registerOption:'o' long:@"output" description:@"output file path" flags:GBOptionOptionalValue];
    
}

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
        GBOptionsHelper *options = [[GBOptionsHelper alloc] init];
        registerOptions(options);
        
        GBCommandLineParser *parser = [[GBCommandLineParser alloc] init];
        [parser registerSettings:[GBSettings settingsWithName:@"Factory" parent:nil]];
        [parser registerOptions:options];
        if (![parser parseOptionsWithArguments:argv count:argc]) {
            gbprintln(@"Errors in command line parameters!");
            gbprintln(@"");
            [options printHelp];
            return 1;
        }
        
        if ([[parser valueForOption:@"ver"] boolValue]) {
            gbprintln(@"\"%@\"", version);
            return 0;
        }
        
        if ([[parser valueForOption:@"clean"] boolValue]) {
            [[NSFileManager defaultManager] removeItemAtPath:[MetaBuildSettings MetaIntermediatesDir] error:nil];
        }
        
        PostBuildAction* action = [[PostBuildAction alloc] initWithMetaToolPath:[parser valueForOption:@"meta"] outputFile:[parser valueForOption:@"output"]];
        [action doAction];
    }
    return 0;
}
