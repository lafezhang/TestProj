//
//  MetaDB.h
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/23.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MetaHash : NSObject

- (id)initWithHashFilePath:(NSString*)filePath;
- (void)save;
@property (nonatomic) NSDate* projectFileVersion;
@property (nonatomic) NSDate* pchVersion;
@property (nonatomic) NSString* xcodeCommand;

@end
