//
//  BuildEnvoriment.h
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/20.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>

#define EN(x) ([BuildEnvoriment envorimentValueForKey:x])

@interface BuildEnvoriment : NSObject

+ (void)setEnviromentFilePath:(NSString*)path;

+ (NSString*)envorimentValueForKey:(NSString*)key;

+ (NSDictionary*)envoriment;

@end
