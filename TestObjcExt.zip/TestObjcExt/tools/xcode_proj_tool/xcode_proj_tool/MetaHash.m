//
//  MetaDB.m
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/23.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import "MetaHash.h"

@implementation MetaHash
{
    NSString* _hashFilePath;
    NSMutableDictionary* _db;
}

- (id)initWithHashFilePath:(NSString *)filePath
{
    if (self = [super init]) {
        _hashFilePath = filePath;
        _db = [NSMutableDictionary dictionaryWithContentsOfFile:filePath];
        if (!_db) {
            _db = [NSMutableDictionary dictionary];
        }
        
        _projectFileVersion = _db[@"proj"];
        _pchVersion = _db[@"pch"];
        _xcodeCommand = _db[@"cm"];
    }
    return self;
}

- (void)save
{
    _db[@"proj"] = _projectFileVersion;
    _db[@"pch"] = _pchVersion;
    _db[@"cm"] = _xcodeCommand;
    [_db writeToFile:_hashFilePath atomically:YES];
}

@end
