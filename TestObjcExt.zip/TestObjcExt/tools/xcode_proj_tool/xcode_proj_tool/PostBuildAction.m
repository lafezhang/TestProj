//
//  PostBuildAction.m
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/10.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import "PostBuildAction.h"
#import "FileHelper.h"
#import "NSString+MD5.h"
#import "BuildEnvoriment.h"
#import "MetaHash.h"
#import "MetaBuildSettings.h"

@interface MetaDBItem : NSObject<NSCoding>

@property (nonatomic) NSString* objFileName;
@property (nonatomic) NSString* metaJson;
@property (nonatomic) NSDate* objFileVersion;

@end

@implementation MetaDBItem

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        _objFileName = [aDecoder decodeObjectForKey:@"n"];
        _metaJson = [aDecoder decodeObjectForKey:@"j"];
        _objFileVersion = [aDecoder decodeObjectForKey:@"v"];
    }
    return self;
}
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:_objFileName forKey:@"n"];
    if (_metaJson.length > 0) {
        [aCoder encodeObject:_metaJson forKey:@"j"];
    }
    [aCoder encodeObject:_objFileVersion forKey:@"v"];
}

@end

@implementation PostBuildAction
{
    NSMutableDictionary* _buildLogForEachObjFile;
    
    NSMutableDictionary* _replacedPCHFiles;
    NSMutableDictionary* _xcodePCHHashes;
    
    NSMutableArray* _metaCommands;
    NSString* _metaToolPath;
    NSString* _clangInclude;
    NSString* _cppInclude;
    
    NSString* _clangToolBinPath;
    
    NSString* _rawPchPath;
    BOOL _needCompilePCH;
    NSString* _outputFile;
    
    MetaHash* _metaHash;
}

- (id)initWithMetaToolPath:(NSString *)metaToolPath outputFile:(NSString *)outputFile
{
    if (self = [super init]) {
        _metaToolPath = metaToolPath;
        _outputFile = outputFile;
        _metaHash = [[MetaHash alloc] initWithHashFilePath:[MetaBuildSettings MetaHashFile]];
        
        _clangToolBinPath = [EN(@"TOOLCHAIN_DIR") stringByAppendingPathComponent:@"usr/bin/clang"];
        
    }
    return self;
}

- (void)doAction
{
    // 根据工程文件版本号，决定是否要重新生成编译命令
    NSDate* projVersion = [FileHelper lastModificationTimeOfFile:[MetaBuildSettings ProjectFilePath]];
    
    NSString* xcodeCommandLine = [self xcodeBuildCommandLine];
    
    if (![xcodeCommandLine isEqualToString:_metaHash.xcodeCommand] || ![projVersion isEqualToDate:_metaHash.projectFileVersion]) {
        [self genrateBuildCommands:xcodeCommandLine];
    }
    
    // 获取最近编译的预编译头文件
    
    _rawPchPath = [[MetaBuildSettings SRCROOT] stringByAppendingPathComponent:EN(@"GCC_PREFIX_HEADER")];
    
    NSString* pchFileName = [_rawPchPath.lastPathComponent stringByDeletingPathExtension];
    
    NSDate* pchVersion;
    for (NSString* folder in [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[MetaBuildSettings BuildPCHRoot] error:nil]) {
        if ([folder hasPrefix:pchFileName]) {
            NSString* compiledPchName = [_rawPchPath.lastPathComponent stringByAppendingPathExtension:@"pch"];
            NSString* compiledPch = [[[MetaBuildSettings BuildPCHRoot] stringByAppendingPathComponent:folder] stringByAppendingPathComponent:compiledPchName];
            NSDate* d = [FileHelper lastModificationTimeOfFile:compiledPch];
            if (!pchVersion || [d compare:pchVersion] == NSOrderedDescending) {
                pchVersion = d;
            }
        }
    }
    // 根据pch文件版本号，决定是否要重新生成预编译头文件
    if (![pchVersion isEqualToDate:_metaHash.pchVersion]) {
        _needCompilePCH = YES;
    }
    
    // 解析编译命令，提取出针对每一个.o文件所使用的编译命令
    [self parseBuildLogs];
    
    NSMutableDictionary* metaDB = [NSKeyedUnarchiver unarchiveObjectWithFile:[MetaBuildSettings MetaDBFile]];
    if (!metaDB) {
        metaDB = [NSMutableDictionary dictionary];
    }
    
    NSArray* objFiles = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:[MetaBuildSettings BuildIntermediatesDir] error:nil];
    NSDate* now = [NSDate new];
    NSMutableArray* filesToProcess = [NSMutableArray array];
    _metaCommands = [NSMutableArray array];
    for (NSString* fileName in objFiles) {
        if ([fileName.pathExtension isEqualToString:@"o"]) {
            NSString* objFilePath = [[MetaBuildSettings BuildIntermediatesDir] stringByAppendingPathComponent:fileName];
            NSString* compileC = _buildLogForEachObjFile[objFilePath];
            if (compileC.length == 0) {
                // 这个表示源文件已经从工程中被删除
                [metaDB removeObjectForKey:fileName];
                continue;
            }
            NSString* metaCommand = [self handleCompileC:compileC];
            
            metaCommand = [NSString stringWithFormat:@"%@ %@", _metaToolPath, metaCommand];
            NSDate* modifyTime = [FileHelper lastModificationTimeOfFile:objFilePath];
            MetaDBItem* dbItem = metaDB[fileName];
            if (![dbItem.objFileVersion isEqualToDate:modifyTime]) {
                [filesToProcess addObject:@{@"c": metaCommand, @"n":fileName, @"v":modifyTime}];
            }
            [_metaCommands addObject:metaCommand];
        }
    }
    
    int totalCount = (int)filesToProcess.count;
    __block int processedCount = 0;
    dispatch_queue_t sync = dispatch_queue_create("", DISPATCH_QUEUE_SERIAL);
    
    if (filesToProcess.count > 0) {
        
        NSOperationQueue* queue = [[NSOperationQueue alloc] init];
//        queue.maxConcurrentOperationCount = 6;
        queue.suspended = NO;
        for (NSDictionary* file in filesToProcess) {
            NSBlockOperation* operation = [NSBlockOperation blockOperationWithBlock:^{
                @autoreleasepool {
                    // 这个源文件需要重新处理
                    
                    NSString* exeCommand = file[@"c"];
                    NSString* fileName = file[@"n"];
                    NSDate* v = file[@"v"];
                    static int i = 0;
                    i++;
                    if (i==2) {
                        
                        [self runCommand:@"export"];
                    }
                    NSString* outPut = [self runCommand:exeCommand];
                    dispatch_sync(sync, ^{
                        processedCount++;
                        NSLog(@"processed: %d / %d", processedCount, totalCount);
                        
                        MetaDBItem* item = [metaDB objectForKey:fileName];
                        if (!item) {
                            item = [[MetaDBItem alloc] init];
                            metaDB[fileName] = item;
                        }
                        item.metaJson = outPut;
                        item.objFileVersion = v;
                        item.objFileName = fileName;
                    });
                }
            }];
            [queue addOperation:operation];
        }
        [queue waitUntilAllOperationsAreFinished];
    }
    [NSKeyedArchiver archiveRootObject:metaDB toFile:[MetaBuildSettings MetaDBFile]];
    [[_metaCommands componentsJoinedByString:@"\n\n"] writeToFile:[MetaBuildSettings MetaCommandsFile] atomically:YES encoding:NSUTF8StringEncoding error:nil];
    [self generateMetaFile:metaDB];
    NSLog(@"meta_time:%f", [[NSDate new] timeIntervalSinceDate:now]);
    _metaHash.pchVersion = pchVersion;
    _metaHash.projectFileVersion = projVersion;
    _metaHash.xcodeCommand = xcodeCommandLine;
    [_metaHash save];
}

- (void)generateMetaFile:(NSDictionary*)metaDB
{
    NSMutableDictionary* metaInfos = [NSMutableDictionary dictionary];
    for (MetaDBItem* item in metaDB.allValues) {
        if (item.metaJson.length > 0) {
            NSDictionary* classMeta = [NSJSONSerialization JSONObjectWithData:[item.metaJson dataUsingEncoding:NSUTF8StringEncoding]  options:0 error:nil];
            [classMeta enumerateKeysAndObjectsUsingBlock:^(id key, NSDictionary*  obj, BOOL * stop) {
                if ([obj[@"has_ext"] isEqualToString:@"1"]) {
                    NSMutableDictionary* m = [obj mutableCopy];
                    [m removeObjectForKey:@"has_ext"];
                    metaInfos[key] = m;
                }
            }];
        }
    }
    
    NSData* data = [NSJSONSerialization dataWithJSONObject:metaInfos options:NSJSONWritingPrettyPrinted error:nil];
    NSString* json =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"metas:\n%@",json);
    NSError* error;
    NSString* folder = [_outputFile stringByDeletingLastPathComponent];
    if (![FileHelper fileExistsWithPath:folder]) {
        [FileHelper createDirectoryWithPath:folder];
    }
    [json writeToFile:_outputFile atomically:YES encoding:NSUTF8StringEncoding error:&error];
    if (error) {
        NSLog(@"error:%@",error);
    }
}

- (NSString *)runCommand:(NSString *)commandToRun
{
    
    NSTask *task = [[NSTask alloc] init];
    [task setLaunchPath:@"/bin/sh"];
    
    NSString* exportDLPath = [NSString stringWithFormat:@"export DYLD_LIBRARY_PATH=%@", [EN(@"TOOLCHAIN_DIR") stringByAppendingPathComponent:@"usr/lib"]];
    
    NSArray *arguments = [NSArray arrayWithObjects:
                          @"-c" ,
                          [NSString stringWithFormat:@"%@ && %@", exportDLPath, commandToRun],
                          nil];
    if ([MetaBuildSettings isInRDM]) {
        NSLog(@"run command:%@", commandToRun);
    }
    [task setArguments:arguments];
    
    NSPipe *pipe = [NSPipe pipe];
    [task setStandardOutput:pipe];
    
    NSFileHandle *file = [pipe fileHandleForReading];
    
    [task launch];
    
    NSData *data = [file readDataToEndOfFile];
    
    NSString *output = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return output;
}

- (NSString*)xcodeBuildCommandLine
{
    NSString* outputFile = [MetaBuildSettings XcodeBuildCommandsFile];
    NSString* shell;
    if ([MetaBuildSettings isInRDM]) {
        shell= [NSString stringWithFormat:@"xcodebuild -project %@ -target %@ -sdk iphoneos -configuration %@ CLANG_ENABLE_MODULE_DEBUGGING=NO SYMROOT=%@ -dry-run > %@", [MetaBuildSettings ProjectFilePath],  EN(@"TARGETNAME"), EN(@"CONFIGURATION"), [MetaBuildSettings dryRunBuildRoot], outputFile];
    }
    else {
        
        shell = [NSString stringWithFormat:@"xcodebuild -scheme %@ -target %@ -arch %@ -sdk %@ -configuration %@ CLANG_ENABLE_MODULE_DEBUGGING=NO -derivedDataPath %@ -dry-run > %@", EN(@"PROJECT_NAME"), EN(@"TARGET_NAME"), [MetaBuildSettings BuildingForArch], EN(@"PLATFORM_NAME"), EN(@"CONFIGURATION"), [MetaBuildSettings dryRunBuildRoot], outputFile];
    }
    return shell;
}

- (void)genrateBuildCommands:(NSString*)xcodeCommandLine
{
    NSString* outputFile = [MetaBuildSettings XcodeBuildCommandsFile];
    [FileHelper deleteFileWithPath:outputFile];
    [FileHelper createDirectoryWithPath:[MetaBuildSettings MetaIntermediatesDir]];
    [FileHelper createFileWithPath:outputFile];
    [FileHelper deleteFileWithPath:[MetaBuildSettings dryRunBuildRoot]];
    [[NSFileManager defaultManager] changeCurrentDirectoryPath:EN(@"SRCROOT")];
    
    
    NSLog(@"commands:%@", xcodeCommandLine);
    system(xcodeCommandLine.UTF8String);
}

- (NSString*)replaceDevicedDataPath:(NSString*)stringToReplace
{
    NSString* origiDerivedDataPath;
    if ([MetaBuildSettings isInRDM]) {
        origiDerivedDataPath = EN(@"SYMROOT");
    }
    else
        origiDerivedDataPath = [[EN(@"BUILD_DIR") stringByDeletingLastPathComponent] stringByDeletingLastPathComponent];
//    NSLog(@"replacing:%@, %@ with %@", )
    NSString* result = [stringToReplace stringByReplacingOccurrencesOfString:[MetaBuildSettings dryRunBuildRoot] withString:origiDerivedDataPath];
    return result;
}
- (void)parseBuildLogs
{
    _buildLogForEachObjFile = [NSMutableDictionary dictionary];
    NSString* outputFile = [MetaBuildSettings XcodeBuildCommandsFile];
    NSString* buildLogs = [NSString stringWithContentsOfFile:outputFile encoding:NSUTF8StringEncoding error:nil];
    
    NSString* targetSection = [NSString stringWithFormat:@"=== BUILD TARGET %@", EN(@"TARGET_NAME")];
    NSString* targetSectionBuildLog = [buildLogs substringFromIndex:[buildLogs rangeOfString:targetSection].location];
    NSArray* buildCommands = [targetSectionBuildLog componentsSeparatedByString:@"\n\n"];
    
    for (NSString* buildCommand in buildCommands) {
        if ([buildCommand hasPrefix:@"ProcessPCH"]) {
            NSArray* lines = [buildCommand componentsSeparatedByString:@"\n"];
            
            NSString* brief = lines[0];
            NSArray* components = [brief componentsSeparatedByString:@" "];
            NSString* outputPath = [components objectAtIndex:1];
            
            NSString* outputDir = [outputPath stringByDeletingLastPathComponent];
            [FileHelper createDirectoryWithPath:outputDir];
            
            if (_needCompilePCH || ![FileHelper fileExistsWithPath:outputPath]) {
                NSString* pchCommand = [self handleProcessPCH:lines.lastObject];
                NSLog(@"pchCommand:%@", pchCommand);
                system(pchCommand.UTF8String);
            }
        }
        else if ([buildCommand hasPrefix:@"CompileC"])
        {
            NSArray* lines = [buildCommand componentsSeparatedByString:@"\n"];
            
            NSString* brief = lines[0];
            NSString* objPath = [[brief componentsSeparatedByString:@" "] objectAtIndex:1];
            if (![objPath hasPrefix:@"/"]) {
                objPath = [[EN(@"SYMROOT") stringByDeletingLastPathComponent] stringByAppendingPathComponent:objPath];
            }
            NSString* replacced = [self replaceDevicedDataPath:objPath];
            _buildLogForEachObjFile[replacced] = lines.lastObject;
        }
    }
    
}

- (NSString*)handleCompileC:(NSString*)compileC
{
    compileC = [compileC stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSArray* commandComponents = [compileC componentsSeparatedByString:@" "];
    NSUInteger count = commandComponents.count;
    NSString* srcPath = commandComponents[count - 3];
    NSMutableArray* finnalCommand = [NSMutableArray array];
    [finnalCommand addObject:srcPath];
    
    for (NSInteger i = 1; i < count - 4; i++) {
        NSString* cc = commandComponents[i];
        if ([cc isEqualToString:@"-gmodules"]) {
            continue;
        }
        if ([cc hasPrefix:@"-fmodules"]) {
            continue;
        }
        
        if ([cc hasPrefix:@"-fbuild-session"]) {
            continue;
        }
        
        if ([cc hasSuffix:@".pch"]) {
            [finnalCommand addObject:cc];
        }
        else {
            [finnalCommand addObject:[self replaceDevicedDataPath:cc]];
        }
    }
    [finnalCommand addObject:@"-fsyntax-only"];
    [finnalCommand addObject:@"-isystem "];
    return [finnalCommand componentsJoinedByString:@" "];
}

- (NSString*)handleProcessPCH:(NSString*)command
{
    command = [command stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    NSArray* commandComponents = [command componentsSeparatedByString:@" "];
    NSUInteger count = commandComponents.count;
    NSMutableArray* finnalCommand = [NSMutableArray array];
    [finnalCommand addObject:_clangToolBinPath];
    
    BOOL hasPastOutput = NO;
    
    for (NSInteger i = 1; i < count; i++) {
        NSString* cc = commandComponents[i];
        if ([cc isEqualToString:@"-o"]) {
            hasPastOutput = YES;
        }
        if ([cc isEqualToString:@"-MF"]) {
            i++;
            continue;
        }
        if ([cc hasPrefix:@"-fmodules"]) {
            continue;
        }
        
        if ([cc hasPrefix:@"-fbuild-session"]) {
            continue;
        }
        
        if (!hasPastOutput) {
            [finnalCommand addObject:[self replaceDevicedDataPath:cc]];
        }
        else {
            [finnalCommand addObject:cc];
        }
    }
    
    return [finnalCommand componentsJoinedByString:@" "];
}

@end
