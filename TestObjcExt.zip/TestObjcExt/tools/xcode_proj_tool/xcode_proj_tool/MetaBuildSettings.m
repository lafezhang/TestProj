//
//  Helpers.m
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/10.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import "MetaBuildSettings.h"
#include <sys/stat.h>
#import "BuildEnvoriment.h"
@implementation MetaBuildSettings

+ (NSString*)ProductDir
{
    return EN(@"BUILT_PRODUCTS_DIR");
}

+ (NSString*)ProjectFilePath
{
    return EN(@"PROJECT_FILE_PATH");
    
}

+ (NSString*)MetaIntermediatesDir
{
    return [[self ProductDir] stringByAppendingPathComponent:@"meta_Intermediates"];
}

+ (NSString*)XcodeBuildCommandsFile
{
    return [[self MetaIntermediatesDir] stringByAppendingPathComponent:@"xcode_commands"];
}

+ (NSString*)SRCROOT
{
    return EN(@"SRCROOT");
}

+ (NSString*)BuildingForArch
{
    static NSString*firstArch;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString* arches = EN(@"ARCHS");
        NSString* firstArch1 = [[arches componentsSeparatedByString:@" "] firstObject];
        if ([firstArch1 hasPrefix:@"\""]) {
            firstArch1 = [firstArch substringFromIndex:1];
        }
        firstArch = firstArch1;
    });
    return firstArch;
}

+ (NSString*)BuildIntermediatesDir
{
    return [EN(@"OBJECT_FILE_DIR_normal") stringByAppendingPathComponent:[self BuildingForArch]];
}

+ (NSString*)MetaPCHRoot
{
    return [[self dryRunBuildRoot] stringByAppendingPathComponent:@"Build/Intermediates/PrecompiledHeaders"];
}

+ (NSString*)BuildPCHRoot
{
    return EN(@"SHARED_PRECOMPS_DIR");
}

+ (NSString*)dryRunBuildRoot
{
    return [EN(@"CONFIGURATION_BUILD_DIR") stringByAppendingPathComponent:@"dry_run_root"];
}

+ (NSString*)MetaCommandsFile
{
    return [[self MetaIntermediatesDir] stringByAppendingPathComponent:@"meta_commands"];
}

+ (NSString*)MetaDBFile
{
    return [[self MetaIntermediatesDir] stringByAppendingPathComponent:@"meta_db"];
}

+ (NSString*)MetaHashFile
{
    return [[self MetaIntermediatesDir] stringByAppendingPathComponent:@"meta_hash"];
}

+ (BOOL)isInRDM
{
    return [EN(@"CI") length] > 0;
}

@end
