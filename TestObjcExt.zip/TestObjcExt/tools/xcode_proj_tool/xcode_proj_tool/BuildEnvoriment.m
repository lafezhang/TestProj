//
//  BuildEnvoriment.m
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/20.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import "BuildEnvoriment.h"

static NSDictionary* myEnv;

@implementation BuildEnvoriment

+ (void)setEnviromentFilePath:(NSString *)path
{
    NSString* en = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    NSArray* lines = [en componentsSeparatedByString:@"\n"];
    NSMutableDictionary* dict = [NSMutableDictionary dictionary];
    for (NSString* line in lines) {
        if (line.length == 0) continue;
        NSArray* components = [line componentsSeparatedByString:@"="];
        NSString* key = components.firstObject;
        NSString* value = components.count > 1 ? components.lastObject : @"";
        dict[key] = value;
    }
    myEnv = dict;
}

+ (NSString*)envorimentValueForKey:(NSString *)key
{
    static NSDictionary* env;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        env = [[NSProcessInfo processInfo] environment];
    });
    if (env[key]) {
        return env[key];
    }
    
    return myEnv[key];
}

+ (NSDictionary*)envoriment
{
    NSMutableDictionary* dict = [[[NSProcessInfo processInfo] environment] mutableCopy];
    [dict addEntriesFromDictionary:myEnv];
    return dict;
}

@end
