//
//  Helpers.h
//  xcode_proj_tool
//
//  Created by zhang on 2017/3/10.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MetaBuildSettings : NSObject

+ (NSString*)ProductDir;
+ (NSString*)ProjectFilePath;
+ (NSString*)MetaIntermediatesDir;
+ (NSString*)MetaPCHRoot;
+ (NSString*)XcodeBuildCommandsFile;
+ (NSString*)BuildIntermediatesDir;
+ (NSString*)BuildPCHRoot;
+ (NSString*)SRCROOT;
+ (NSString*)BuildingForArch;

+ (NSString*)dryRunBuildRoot;

+ (NSString*)MetaCommandsFile;
+ (NSString*)MetaDBFile;
+ (NSString*)MetaHashFile;

+ (BOOL)isInRDM;

@end
