//
//  FileHelper.h
//  QQLiveHD
//
//  Created by jordenwu-Mac on 10-8-20.
//  Copyright 2010 tencent.com. All rights reserved.


/**
 * 文件管理的工具类
 */
@import Foundation;

@interface FileHelper : NSObject {
}
@end


@interface FileHelper (files)
/**
 * 如果文件不存在，则创建之，然后设置iCloud属性
 */
+ (void)checkAndCreateFileAtPath:(NSString *)filePath iCloud:(BOOL)iCloud;

/**
 * 对文件夹或文件设置iCloud的 Do Not Backup属性
 */
+ (BOOL)addSkipBackupAttributeToURL:(NSURL *)URL;

/**
 * 创建文件
 */
+ (BOOL)createFileWithPath:(NSString *)filePath;

/**
 * 文件是否存在
 */
+ (BOOL)fileExistsWithPath:(NSString *)filePath;

/**
 * 删除文件
 */
+ (BOOL)deleteFileWithPath:(NSString *)filePath;

/**
 * 创建目录
 */
+ (BOOL)createDirectoryWithPath:(NSString *)dirPath;

/**
 * 目录是否存在
 */
+ (BOOL)directoryExistsWithPath:(NSString *)dirPath;

/**
 * 删除目录
 */
+ (BOOL)deleteDirectoryWithPath:(NSString *)dirPath;

/**
 * 移动文件
 */
+ (void)moveFile:(NSString*)file ToNewFile:(NSString*)newFile;

/**
 * 复制文件
 */
+ (void)copyFile:(NSString*)file ToNewFile:(NSString*)newFile;

/**
 *递归寻找指定文件名的文件
 */
+(NSString *)findFile:(NSString *)dictionary fileName:(NSString *)fileName;
@end

@interface FileHelper (filesinfo)
/**
 * 获取文件大小（以字节为单位）
 */
+ (unsigned long long)getFileSizeWithPath:(NSString*)filePath;

/**
 * 获取系统可用空间（以字节为单位）
 */
+ (unsigned long long)getFileSystemFreeSize;

/**
 * 判断文件空间是否已满（小于500MB）
 */
+(BOOL)isDiskFull;
@end

@interface FileHelper (paths)
/**
 * 获取程序的Documents目录
 */
+ (NSString *)getDocumentsPath;

/**
 * 获取程序目录的Library目录路径
 */
+ (NSString *)getLibraryPath;

/**
 * 获取程序临时目录路径
 */
+ (NSString *)getTemporaryPath;

/**
 * 获取程序目录的路径
 */
+ (NSString *)getAppPath;


+ (NSDate*)lastModificationTimeOfFile:(NSString*)file;

/**
 *获取info.plist的路径
 */
+ (NSString *)getPlistPath;
@end

@interface FileHelper (imageload)
/**
 *获取缓存图片路径
 */
+ (NSString *)getImageCachePath;
+ (NSString *)getImageCacheFatherPath;
+ (long long)getFolderCacheSize:(NSString*)folderPath;
@end

@interface FileHelper (download)
/**
 *下载列表文件
 */
+ (NSString *)getDownloadListFile;

/**
 *下载视频目录
 */
+ (NSString *)getDownloadMediaDirectory;

/**
 *临时数据下载目录
 */
+ (NSString *)getDownloadTempDirectory;

// 获取小手指临时下载根目录
+ (NSString *)getTempVideoDownloadDirectory;
@end

