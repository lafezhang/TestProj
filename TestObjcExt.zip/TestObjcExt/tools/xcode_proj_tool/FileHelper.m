//
//  FileHelper.m
//  QQMusicForIphoneDemo
//
//  Created by jordenwu-Mac on 10-8-20.
//  Copyright 2010 tencent.com. All rights reserved.
//

#import "FileHelper.h"
#import <sys/xattr.h>
#import <sys/stat.h>

@implementation FileHelper

#pragma  mark files
+ (void)checkAndCreateFileAtPath:(NSString *)filePath iCloud:(BOOL)iCloud
{
    if (! [FileHelper fileExistsWithPath:filePath]) {
        [FileHelper createDirectoryWithPath:filePath];
    }
    if (! iCloud) {
        [FileHelper addSkipBackupAttributeToURL:[NSURL fileURLWithPath:filePath]];
    }
}

+ (BOOL)addSkipBackupAttributeToURL:(NSURL *)URL{
    BOOL success = NO;
    
    NSError *error = nil;
    
    success = [URL setResourceValue:[NSNumber numberWithBool:YES]
                             forKey:NSURLIsExcludedFromBackupKey
                              error:&error];
    
    return success;
}

+ (BOOL)fileExistsWithPath:(NSString *)filePath
{
	return [[NSFileManager defaultManager] fileExistsAtPath:filePath];
}

+ (BOOL)createFileWithPath:(NSString *)filePath
{
	return [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:nil];
}

+ (BOOL)deleteFileWithPath:(NSString *)filePath
{
	return [[NSFileManager defaultManager] removeItemAtPath:filePath error:NULL];
}

+ (BOOL)createDirectoryWithPath:(NSString *)dirPath
{   
	return [[NSFileManager defaultManager] createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil error:nil];
}

+ (BOOL)directoryExistsWithPath:(NSString *)dirPath
{   
	BOOL isDir=YES;
	return [[NSFileManager defaultManager] fileExistsAtPath:dirPath isDirectory:&isDir];
}

+ (BOOL)deleteDirectoryWithPath:(NSString *)dirPath
{
	return [[NSFileManager defaultManager] removeItemAtPath:dirPath error:NULL];
}

+ (void)moveFile:(NSString*)file ToNewFile:(NSString*)newFile
{
    [[NSFileManager defaultManager] moveItemAtPath:file toPath:newFile error:nil];
}

+ (void)copyFile:(NSString*)file ToNewFile:(NSString*)newFile
{
    if(file == nil || newFile == nil)
    {
        return;
    }
    @autoreleasepool {
        [[NSFileManager defaultManager] copyItemAtPath:file toPath:newFile error:nil];
    }
}

+(NSString *)findFile:(NSString *)dictionary fileName:(NSString *)fileName{
    //    system("find /Users/Haywoodfu/ -name '*.png'");
    NSError *error;
    NSArray *pathList = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:dictionary error:&error];
    for (NSString *t_path in pathList) {
        NSString * fullPath = [dictionary stringByAppendingPathComponent:t_path];
        BOOL isDir;
        if ([[NSFileManager defaultManager] fileExistsAtPath:fullPath isDirectory:&isDir]) {
            if ( isDir){
                if ([self findFile:fullPath fileName:fileName] != nil) {
                    return [fullPath stringByAppendingPathComponent:fileName];
                }
            }else if ([t_path isEqualToString:fileName]){
                return t_path;
            }
        }
    }
    return nil;
}

#pragma mark filesinfo
+ (unsigned long long)getFileSizeWithPath:(NSString*)filePath
{
    NSDictionary *attributes = [[NSFileManager defaultManager] attributesOfItemAtPath:filePath error:nil];
    return (unsigned long long)[[attributes objectForKey:NSFileSize] unsignedLongLongValue];
}

+ (unsigned long long)getFileSystemFreeSize{
    NSDictionary *fattributes = [[NSFileManager defaultManager] attributesOfFileSystemForPath:NSHomeDirectory() error:NULL];
    return [[fattributes objectForKey:NSFileSystemFreeSize] unsignedLongLongValue];
}

+(BOOL)isDiskFull{
    long long freespace = [FileHelper getFileSystemFreeSize];
    if(freespace < 1024*1024*560){
        return YES;
    }else{
        return NO;
    }
}

#pragma mark paths
+ (NSString *)getDocumentsPath
{   
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
	return (NSString *)[paths objectAtIndex:0];
}

+ (NSString *)getLibraryPath
{   
	NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);	
	return (NSString *)[paths objectAtIndex:0];
}

+ (NSString *)getTemporaryPath
{
    NSString *path = NSTemporaryDirectory();
    return path;
}

+ (NSString *)getAppPath
{
    return [[NSBundle mainBundle] bundlePath];
}

+(NSString *)getPlistPath
{
    //ios >= 8.0,NSHomeDirectory != [NSBundle mainBundle] bundlePath]
    // NSString *dataPath = [NSHomeDirectory() stringByAppendingPathComponent:@"qqlive.app/Info.plist"];
    NSString *dataPath = [[[NSBundle mainBundle] bundlePath] stringByAppendingPathComponent:@"Info.plist"];
    return dataPath;
}

#pragma mark imageload
+ (NSString *)getImageCachePath
{
    NSString *path = [NSString stringWithFormat:@"%@/Caches/images", [FileHelper getLibraryPath]];
    if (![FileHelper directoryExistsWithPath:path]) {
        [FileHelper createDirectoryWithPath:path];
    }
    return path;
}

+ (NSString *)getImageCacheFatherPath
{
    NSString *path = [NSString stringWithFormat:@"%@/Caches", [FileHelper getLibraryPath]];
    if (![FileHelper directoryExistsWithPath:path]) {
        [FileHelper createDirectoryWithPath:path];
    }
    return path;
}

+ (long long)fileSizeAtPath:(NSString*)filePath
{
    struct stat st;
    if (lstat([filePath cStringUsingEncoding:NSUTF8StringEncoding], &st) == 0) {
        return st.st_size;
    }
    return 0;
}

+ (long long)getFolderCacheSize:(NSString*)folderPath
{
    long long filesz = 0;
    NSFileManager* fm = [NSFileManager defaultManager];
    if (![fm fileExistsAtPath:folderPath])return 0 ;
    NSEnumerator *childFilesEnumerator = [[fm subpathsAtPath:folderPath] objectEnumerator];
    NSString* fileName;
    while ((fileName = [childFilesEnumerator nextObject]) != nil) {
        NSString* fileAbsolutePath = [folderPath stringByAppendingPathComponent:fileName];
        filesz += [self fileSizeAtPath:fileAbsolutePath];
    }
    return filesz;
}

#pragma mark download
+ (NSString *)dataDirectory
{
    return [FileHelper getDocumentsPath];
}

+ (NSString *)getDownloadListFile
{
    return [[FileHelper dataDirectory] stringByAppendingPathComponent:@"downloadlist"];
}

+ (NSString *)getDownloadMediaDirectory
{
    return [[FileHelper dataDirectory] stringByAppendingPathComponent:@"Caches/Media"];
}

+ (NSString *)getDownloadTempDirectory
{
    return [[FileHelper dataDirectory] stringByAppendingPathComponent:@"Caches/Temp"];
}

+ (NSString *)getTempVideoDownloadDirectory
{
    return [[FileHelper dataDirectory] stringByAppendingPathComponent:@"Caches/Finger_Temp"];
}


+ (NSDate*)lastModificationTimeOfFile:(NSString *)file
{
    const char * cFilePath = [file UTF8String];
    if (access(cFilePath, 0) == 0){
        struct stat stat;
        lstat(cFilePath, &stat);
        NSDate* modified = [NSDate dateWithTimeIntervalSince1970:stat.st_mtime];
        return modified;
    }
    return nil;
}

#pragma mark END
@end
