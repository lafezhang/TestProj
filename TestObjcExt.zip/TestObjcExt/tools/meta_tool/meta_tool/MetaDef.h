//
//  MetaDef.h
//  meta_tool
//
//  Created by zhang on 2017/1/20.
//  Copyright © 2017年 zhang. All rights reserved.
//

#ifndef MetaDef_h
#define MetaDef_h


#define Meta_Ext_Prefix @"metaExt_"

#endif /* MetaDef_h */
