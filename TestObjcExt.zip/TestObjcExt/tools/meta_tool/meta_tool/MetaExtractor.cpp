//
//  MetaExtractor.cpp
//  meta_tool
//
//  Created by zhang on 2017/1/19.
//  Copyright © 2017年 zhang. All rights reserved.
//

#include "MetaExtractor.hpp"
extern "C" {
#include "clang-c/Index.h"
}
#include <iostream>

using namespace std;
static map<string, ObjcInterfaceMeta> metas;

string formatedAnnotation(const std::string& clsName, const std::string& annotation)
{
    std::string a (clsName);
    a += "$";
    a += annotation;
    return a;
}
//

std::string getCursorKindName( CXCursorKind cursorKind )
{
    CXString kindName  = clang_getCursorKindSpelling( cursorKind );
    std::string result = clang_getCString( kindName );
    
    clang_disposeString( kindName );
    return result;
}

std::string getCursorSpelling( CXCursor cursor )
{
    CXString cursorSpelling = clang_getCursorSpelling( cursor );
    std::string result      = clang_getCString( cursorSpelling );
    
    clang_disposeString( cursorSpelling );
    return result;
}


CXChildVisitResult visitObcjInterface( CXCursor cursor, CXCursor  parent , CXClientData clientData )
{
    string interfaceName = getCursorSpelling(parent);
    
    
    return CXChildVisit_Continue;
}

void visitObjcInterface(CXCursor interfaceCursor, ObjcInterfaceMeta* currentMeta)
{
    string interfaceName = getCursorSpelling(interfaceCursor);
    clang_visitChildrenWithBlock(interfaceCursor, ^enum CXChildVisitResult(CXCursor cursor, CXCursor parent) {
        
        if (clang_getCursorKind(cursor) == CXCursor_AnnotateAttr) {
            currentMeta->interfaceMetas.push_back(formatedAnnotation(interfaceName, getCursorSpelling(cursor)));
        }
        else if (clang_getCursorKind(cursor) == CXCursor_ObjCPropertyDecl) {
            
            string propName = getCursorSpelling(cursor);
            clang_visitChildrenWithBlock(cursor, ^enum CXChildVisitResult(CXCursor cursor, CXCursor parent) {
                if (clang_getCursorKind(cursor) == CXCursor_AnnotateAttr) {
                    vector<string>& propMetas = currentMeta->propertyMetas[propName];
                    propMetas.push_back(formatedAnnotation(interfaceName, getCursorSpelling(cursor)));
                }
                
                return CXChildVisit_Continue;
            });
        }
        else if (clang_getCursorKind(cursor) == CXCursor_ObjCInstanceMethodDecl) {
            string selectorName = getCursorSpelling(cursor);
            clang_visitChildrenWithBlock(cursor, ^enum CXChildVisitResult(CXCursor cursor, CXCursor parent) {
                if (clang_getCursorKind(cursor) == CXCursor_AnnotateAttr) {
                    vector<string>& propMetas = currentMeta->selectorMetas[selectorName];
                    propMetas.push_back(formatedAnnotation(interfaceName, getCursorSpelling(cursor)));
                }
                
                return CXChildVisit_Continue;
            });
        }
        else if (clang_getCursorKind(cursor) == CXCursor_ObjCSuperClassRef) {
            CXCursor super = clang_getCursorReferenced(cursor);
            visitObjcInterface(super, currentMeta);
        }
        
        return CXChildVisit_Continue;
    });
}

CXChildVisitResult visitToFindObjcImp( CXCursor cursor, CXCursor /* parent */, CXClientData clientData )
{
    if (clang_getCursorKind(cursor) == CXCursor_ObjCImplementationDecl) {
        ObjcInterfaceMeta meta;
        ObjcInterfaceMeta* currentMeta = &meta;
        CXCursor interfaceCursor = clang_getCanonicalCursor(cursor);
        string interfaceName = getCursorSpelling(interfaceCursor);
        
        meta.interfaceName = interfaceName;
        
        visitObjcInterface(interfaceCursor, currentMeta);
        
        metas[interfaceName] = meta;
        return CXChildVisit_Continue;
    }
    
    return CXChildVisit_Continue;
}

map<string, ObjcInterfaceMeta> MetaExtractor::extract()
{
    // parse the command-line args passed to your code
    CXIndex index = clang_createIndex(0, 1);
    CXTranslationUnit translationUnit = clang_parseTranslationUnit
    (index, NULL, argv, argc, NULL, 0,
     CXTranslationUnit_SkipFunctionBodies);
    CXCursor cur = clang_getTranslationUnitCursor(translationUnit);
    clang_visitChildren(cur, visitToFindObjcImp, NULL);
    clang_disposeTranslationUnit(translationUnit);
    clang_disposeIndex(index);
    
    return metas;
}
