//
//  main.m
//  meta_tool
//
//  Created by zhang on 2017/1/19.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MetaExtractor.hpp"
#import "MetaDef.h"


#define NSString(std_string) ([NSString stringWithUTF8String:(std_string).c_str()])

@interface ObjcInterfaceMetaObjc : NSObject

@property (nonatomic) BOOL hasExt;
@property (nonatomic) NSArray* classHierarchy;
@property (nonatomic) NSString* interfaceName;
@property (nonatomic) NSArray* interfaceMetas;
@property (nonatomic) NSDictionary* propertyMetas;
@property (nonatomic) NSDictionary* selectorMetas;

@end
@implementation ObjcInterfaceMetaObjc

- (id)initWithMeta:(ObjcInterfaceMeta*)meta
{
    if (self = [super init]) {
        {
            NSMutableArray* hierarchy = [NSMutableArray array];
            for (auto it = meta->classHierarchy.begin(); it != meta->classHierarchy.end(); ++it) {
                NSString* ttt = NSString(*it);
                [hierarchy addObject:ttt];
            }
            _classHierarchy = hierarchy;
        }
        _interfaceName = NSString(meta->interfaceName);
        {
            NSMutableArray* tmp = [NSMutableArray array];
            NSMutableArray* selfValues = [NSMutableArray array];
            vector<string>::const_iterator it;
            for(it = meta->interfaceMetas.begin(); it != meta->interfaceMetas.end(); ++it)
            {
                NSString* ttt = NSString(*it);
                if ([ttt rangeOfString:Meta_Ext_Prefix].location != NSNotFound) {
                    [tmp addObject:ttt];
                    if ([ttt hasPrefix:_interfaceName]) {
                        [selfValues addObject:[ttt substringFromIndex:_interfaceName.length+1] ];
                    }
                }
            }
            if (tmp.count > 0) {
                _hasExt = YES;
            }
            
            _interfaceMetas = selfValues;
        }
        
        {
            NSMutableDictionary* tmpDict = [NSMutableDictionary dictionary];
            NSMutableDictionary* selfValues = [NSMutableDictionary dictionary];
            for (auto it = meta->propertyMetas.begin(); it != meta->propertyMetas.end(); ++it)
            {
                for (auto aa = it->second.begin(); aa != it->second.end(); ++aa)
                {
                    NSString* AA = NSString(*aa);
                    if ([AA rangeOfString:Meta_Ext_Prefix].location != NSNotFound) {
                        NSString* key = NSString(it->first);
                        NSMutableArray* metasArray = tmpDict[key];
                        if (!metasArray) {
                            metasArray = [NSMutableArray array];
                            tmpDict[key] = metasArray;
                        }
                        [metasArray addObject:AA];
                        
                        if ([AA hasPrefix:_interfaceName]) {
                            
                            NSMutableArray* selfArray = selfValues[key];
                            if (!selfArray) {
                                selfArray = [NSMutableArray array];
                                selfValues[key] = selfArray;
                            }
                            [selfArray addObject:[AA substringFromIndex:_interfaceName.length+1]];
                        }
                        
                    }
                }
            }
            if (tmpDict.count > 0) {
                _hasExt = YES;
            }
            if (selfValues.count > 0) {
                _propertyMetas = selfValues;
            }
        }
        
        {
            
            NSMutableDictionary* tmpDict = [NSMutableDictionary dictionary];
            NSMutableDictionary* selfValues = [NSMutableDictionary dictionary];
            for (auto it = meta->selectorMetas.begin(); it != meta->selectorMetas.end(); ++it)
            {
                for (auto aa = it->second.begin(); aa != it->second.end(); ++aa)
                {
                    NSString* AA = NSString(*aa);
                    if ([AA rangeOfString:Meta_Ext_Prefix].location != NSNotFound) {
                        NSString* key = NSString(it->first);
                        NSMutableArray* metasArray = tmpDict[key];
                        if (!metasArray) {
                            metasArray = [NSMutableArray array];
                            tmpDict[key] = metasArray;
                        }
                        [metasArray addObject:NSString(*aa)];
                        
                        if ([AA hasPrefix:_interfaceName]) {
                            
                            NSMutableArray* selfArray = selfValues[key];
                            if (!selfArray) {
                                selfArray = [NSMutableArray array];
                                selfValues[key] = selfArray;
                            }
                            [selfArray addObject:[AA substringFromIndex:_interfaceName.length+1]];
                        }
                    }
                }
            }
            if (tmpDict.count > 0) {
                _hasExt = YES;
            }
            if (selfValues.count > 0) {
                _selectorMetas = selfValues;
            }
        }
    }
    return self;
}

- (NSDictionary*)dict
{
    NSMutableDictionary* metas = [NSMutableDictionary dictionary];
    if (_interfaceMetas.count > 0) {
        metas[@"class_metas"] = _interfaceMetas;
    }
    if (_propertyMetas.count > 0) {
        metas[@"prop_metas"] = _propertyMetas;
    }
    if (_selectorMetas.count > 0) {
        metas[@"sel_metas"] = _selectorMetas;
    }
    metas[@"has_ext"] = _hasExt ? @"1":@"0";
    return metas;
}

@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        MetaExtractor extrator(argc, argv);
        map<string, ObjcInterfaceMeta> metas = extrator.extract();
     
        NSMutableDictionary* ouput = [NSMutableDictionary dictionary];
        for (auto it = metas.begin(); it != metas.end(); ++ it)
        {
            ObjcInterfaceMetaObjc* objcMeta = [[ObjcInterfaceMetaObjc alloc] initWithMeta:&(it->second)];
            NSDictionary* dict = [objcMeta dict];
            ouput[objcMeta.interfaceName] = [objcMeta dict];
        }
        NSData* data = [NSJSONSerialization dataWithJSONObject:ouput options:NSJSONWritingPrettyPrinted error:nil];
        
        NSString* json =[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        [json writeToFile:@"/dev/stdout" atomically:NO encoding:NSUTF8StringEncoding error:nil];
    }
    return 0;
}
