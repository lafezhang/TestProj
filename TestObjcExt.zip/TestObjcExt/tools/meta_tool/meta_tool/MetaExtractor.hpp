//
//  MetaExtractor.hpp
//  meta_tool
//
//  Created by zhang on 2017/1/19.
//  Copyright © 2017年 zhang. All rights reserved.
//

#ifndef MetaExtractor_hpp
#define MetaExtractor_hpp

#include <stdio.h>
#include <string>
#include <vector>
#include <map>
using namespace std;

class ObjcInterfaceMeta
{
public:
    vector<string> classHierarchy;
    string interfaceName;
    vector<string> interfaceMetas;
    map<string, vector<string> > propertyMetas;
    map<string, vector<string> > selectorMetas;
};

class MetaExtractor
{
    int argc;
    const char **argv;
public:
    MetaExtractor(int argc, const char **argv)
    :argc(argc), argv(argv){};
    
    map<string, ObjcInterfaceMeta> extract();
};

#endif /* MetaExtractor_hpp */
