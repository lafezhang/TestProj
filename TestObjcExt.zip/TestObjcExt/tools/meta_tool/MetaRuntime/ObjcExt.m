//
//  ExtInfo.m
//  QQLiveChild
//
//  Created by zhang on 2017/3/23.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import "ObjcExt.h"
#import "_ObjcExt_Privite.h"
@implementation ObjcExt
{
    NSString* _objc_name;
    Class _associatedClass;
}
- (id)initWithCategory:(NSString *)category kvs:(NSDictionary *)kvs name:(NSString *)name associatedClass:(__unsafe_unretained Class)associatedClass
{
    if (self = [super init]) {
        _category = category;
        _kvs = [kvs copy];
        _objc_name = name;
        _associatedClass = associatedClass;
    }
    return self;
}

- (NSString*)description
{
    NSMutableArray* tt = [NSMutableArray array];
    [_kvs enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
        [tt addObject:[NSString stringWithFormat:@"%@=%@",key,obj]];
    }];
    return  [tt componentsJoinedByString:@"&"];
}

- (NSString*)objc_name
{
    return _objc_name;
}

- (Class)associatedClass
{
    return _associatedClass;
}

@end


@implementation ClassExt

- (Class)cls
{
    return NSClassFromString(self.objc_name);
}

- (NSString*)clsAsString
{
    return self.objc_name;
}

@end

@implementation PropertyExt

- (objc_property_t)property
{
    return class_getProperty(self.associatedClass, self.objc_name.UTF8String);
}

- (NSString*)propertyAsString
{
    return self.objc_name;
}

@end

@implementation SelectorExt

- (SEL)selector
{
    return NSSelectorFromString(self.objc_name);
}

- (NSString*)selectorAsString
{
    return self.objc_name;
}

@end



