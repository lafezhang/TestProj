//
//  ExtDB.h
//  QQLiveChild
//
//  Created by zhang on 2017/3/24.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ObjcExt.h"

@interface ExtDB : NSObject

+ (NSString*)metaJsonFilePath;
+ (NSString*)metas;
+ (NSDictionary*)metaDictionary;

+ (NSArray<Class>*)classes_has_ext;
+ (NSArray<Class>*)classes_with_category:(NSString*)category;
+ (NSArray<ClassExt*>*)ext_of_class:(Class)cls;
+ (ClassExt*)distant_ext_of_class:(Class)cls; // ext_of_class返回数组的第一个对象，如果你确定某个类只有一个扩展，那么这个方法很有用

+ (NSArray<PropertyExt*>*)prop_ext_of_class:(Class)cls;
+ (NSArray<PropertyExt*>*)prop_ext_of_class:(Class)cls category:(NSString*)catgory;
+ (NSArray<PropertyExt*>*)prop_ext_of_class:(Class)cls prop_name:(const char*)prop_name;

+ (NSArray<SelectorExt*>*)sel_ext_of_class:(Class)cls;
+ (NSArray<SelectorExt*>*)sel_ext_of_class:(Class)cls category:(NSString*)catgory;
+ (NSArray<SelectorExt*>*)sel_ext_of_class:(Class)cls sel:(SEL)sel;
+ (SelectorExt*)distance_sel_ext_of_class:(Class)cls sel:(SEL)sel;

+ (NSDictionary<NSString*, NSArray<ObjcExt*>* >*)indexExtArray:(NSArray<ObjcExt*>*)extArray;
+ (NSArray<ObjcExt*>*)fileterExtArray:(NSArray<ObjcExt*>*)extArray matches:(NSDictionary*)matches;

@end
