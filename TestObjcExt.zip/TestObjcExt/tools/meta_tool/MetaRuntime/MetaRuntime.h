//
//  MetaRuntime.h
//  MetaRuntime
//
//  Created by zhang on 2017/3/23.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import "ObjcExt.h"

#define __Meta_Ext_Token(key, value) key "=" value

#define __Meta_Ext_Token_2(key, value, ...) __Meta_Ext_Token(key, value)
#define __Meta_Ext_Token_4(key, value, ...) __Meta_Ext_Token_2(key, value)"&" __Meta_Ext_Token_2(__VA_ARGS__)
#define __Meta_Ext_Token_6(key, value, ...) __Meta_Ext_Token_2(key, value)"&" __Meta_Ext_Token_4(__VA_ARGS__)
#define __Meta_Ext_Token_8(key, value, ...) __Meta_Ext_Token_2(key, value)"&" __Meta_Ext_Token_6(__VA_ARGS__)
#define __Meta_Ext_Token_10(key, value, ...) __Meta_Ext_Token_2(key, value)"&" __Meta_Ext_Token_8(__VA_ARGS__)
#define __Meta_Ext_Token_12(key, value, ...) __Meta_Ext_Token_2(key, value)"&" __Meta_Ext_Token_12(__VA_ARGS__)
#define __Meta_Ext_Token_14(key, value, ...) __Meta_Ext_Token_2(key, value)"&" __Meta_Ext_Token_14(__VA_ARGS__)
#define __Meta_Ext_Token_16(key, value, ...) __Meta_Ext_Token_2(key, value)"&" __Meta_Ext_Token_16(__VA_ARGS__)
#define __Meta_Ext_Token_18(key, value, ...) __Meta_Ext_Token_2(key, value)"&" __Meta_Ext_Token_18(__VA_ARGS__)

#define __GET_MACRO(_1,_2,_3,_4,_5,_6,_7,_8,_9,_10,_11,_12_,_13,_14,_15,_16,_17,_18,NAME,...) NAME
#define __Token(...) \
__GET_MACRO(__VA_ARGS__,__Meta_Ext_Token_18,_17,__Meta_Ext_Token_16,_15,__Meta_Ext_Token_14,_13,__Meta_Ext_Token_12,_11,__Meta_Ext_Token_10,_9,__Meta_Ext_Token_8,_7,__Meta_Ext_Token_6,_5,__Meta_Ext_Token_4,_3,__Meta_Ext_Token_2, _1)(__VA_ARGS__)


#define __Meta_Ext__(v)  __attribute__((annotate("metaExt_?" v)))
#define __Meta_Ext_(v) __Meta_Ext__(v)
#define Meta_Ext(...) __Meta_Ext_(__Token(__VA_ARGS__))

#define K_Cate "__cate__"

#define Meta_Ext_Cate(cate_name, ...) Meta_Ext(K_Cate,cate_name, ## __VA_ARGS__)

#import "ExtDB.h"

/*
 Meta_Ext(key1, value1, key2, value2, ...)
 Meta_Ext_Cate(cateName, , key1, value1, key2, value2, ...)
 @interface MyDBTable : NSObject
 
 @end
 */


