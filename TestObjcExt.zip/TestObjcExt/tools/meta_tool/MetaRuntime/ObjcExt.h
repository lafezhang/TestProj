//
//  ExtInfo.h
//  QQLiveChild
//
//  Created by zhang on 2017/3/23.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
@interface ObjcExt : NSObject

@property (nonatomic, readonly) NSString* category;
@property (nonatomic, readonly) NSDictionary* kvs;

@end

@interface ClassExt : ObjcExt

@property (nonatomic, readonly) Class cls;
@property (nonatomic, readonly) NSString* clsAsString;

@end

@interface PropertyExt : ObjcExt

@property (nonatomic, readonly) objc_property_t property;
@property (nonatomic, readonly) NSString* propertyAsString;

@end

@interface SelectorExt : ObjcExt

@property (nonatomic, readonly) SEL selector;
@property (nonatomic, readonly) NSString* selectorAsString;

@end
