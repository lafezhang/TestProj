//
//  ExtDB.m
//  QQLiveChild
//
//  Created by zhang on 2017/3/24.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import "ExtDB.h"
#import <objc/runtime.h>
#import "_ObjcExt_Privite.h"
#import "MetaRuntime.h"

NSString* __prettyArray(NSArray* array)
{
    NSArray* des = [array valueForKey:@"description"];
    return [NSString stringWithFormat:@"[%@]", [des componentsJoinedByString:@", "]];
}

NSString* __prettyDict(NSDictionary* dict)
{
    NSMutableArray* des = [NSMutableArray array];
    [dict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, NSArray*  _Nonnull obj, BOOL * _Nonnull stop) {
        [des addObject:[NSString stringWithFormat:@"%@ : %@", key, __prettyArray(obj)]];
    }];
    return [NSString stringWithFormat:@"{%@}", [des componentsJoinedByString:@"; "]];
}

@interface ObjcClassNode : NSObject

@property (nonatomic) Class cls;
@property (nonatomic) NSMutableSet<ObjcClassNode*>* subNodes;
@property (nonatomic, weak) ObjcClassNode* superNode;

@property (nonatomic) NSArray<ClassExt*>* clsExts;
@property (nonatomic) NSDictionary<NSString*, NSArray<PropertyExt*>*>* propExts;
@property (nonatomic) NSDictionary<NSString*, NSArray<SelectorExt*>*>* selExts;

- (id)initWithMetaDefines:(NSDictionary*)defines;
@end
@implementation ObjcClassNode
{
    NSDictionary* _metaDefines;
    BOOL _expanded;
}

- (id)initWithMetaDefines:(NSDictionary *)defines
{
    if (self = [super init]) {
        _metaDefines = defines;
        _expanded = NO;
    }
    return self;
}

- (BOOL)hasExpanded
{
    return _expanded;
}
- (void)expand
{
    if (_expanded) {
        return;
    }
    _expanded = YES;
    
    if (self.superNode && ![self.superNode hasExpanded]) {
        [self.superNode expand];
    }
    
    NSArray* clsMeta = _metaDefines[@"class_metas"];
    NSArray<ClassExt*>* clsExt = [self objcExtsFromMetasArray:clsMeta objcName:NSStringFromClass(self.cls) ext_class:[ClassExt class] associatedClass:self.cls];
    _clsExts = (id)[self mergeExtByOverideSameCategory:clsExt super_ext:self.superNode.clsExts];
    
    [@{@"prop_metas":@[@"propExts", [PropertyExt class]], @"sel_metas":@[@"selExts", [SelectorExt class]]} enumerateKeysAndObjectsUsingBlock:^(NSString* key, NSArray* obj, BOOL * _Nonnull stop) {
        NSDictionary* propMetas = _metaDefines[key];
        NSMutableDictionary* propExts = [NSMutableDictionary dictionary];
        [propMetas enumerateKeysAndObjectsUsingBlock:^(NSString* prop,  NSArray* prop_metas, BOOL * _Nonnull stop) {
            NSArray* tmp =[self objcExtsFromMetasArray:prop_metas objcName:prop ext_class:obj.lastObject associatedClass:self.cls];
            propExts[prop] = tmp;
        }];
        
        NSMutableSet* allProps = [NSMutableSet setWithArray:self.superNode.propExts.allKeys];
        [allProps addObjectsFromArray:propExts.allKeys];
        
        NSMutableDictionary* merged = [NSMutableDictionary dictionary];
        for (NSString* p in allProps) {
            merged[p] = [self mergeExtByOverideSameCategory:propExts[p] super_ext:self.superNode.propExts[p]];
        }
        
        [self setValue:merged forKey:obj.firstObject];
    }];
}

- (void)expandRecursively
{
    [self expand];
    for (ObjcClassNode* sub in _subNodes) {
        [sub expandRecursively];
    }
}

- (NSArray<ObjcExt*>*)mergeExtByOverideSameCategory:(NSArray<ObjcExt*>*)subExt super_ext:(NSArray<ObjcExt*>*)super_ext
{
    NSMutableDictionary* dict = [NSMutableDictionary dictionary];
    for (ObjcExt* s_e in super_ext) {
        NSAssert(s_e.category.length > 0, @"必须指定category");
        dict[s_e.category] = s_e;
    }
    for (ObjcExt* sub_ext in subExt) {
        dict[sub_ext.category] = sub_ext;
    }
    return dict.allValues;
}

- (void)addSubNode:(ObjcClassNode*)subNode
{
    if (!_subNodes) {
        _subNodes = [NSMutableSet set];
    }
    [_subNodes addObject:subNode];
    subNode.superNode = self;
}

- (NSDictionary*)metaKVsFromString:(NSString*)metaString
{
    NSMutableDictionary* dict = [NSMutableDictionary dictionary];
    NSArray* metas = [[metaString substringFromIndex:[@"metaExt_?" length]] componentsSeparatedByString:@"&"];
    for (NSString* mm in metas) {
        NSArray* kvs = [mm componentsSeparatedByString:@"="];
        dict[kvs.firstObject] = kvs.lastObject;
    }
    return dict;
}

- (NSArray*)objcExtsFromMetasArray:(NSArray*)metasArray objcName:(NSString*)objcName ext_class:(Class)ext_class associatedClass:(Class)associatedClass
{
    NSMutableArray* exts = [NSMutableArray array];
    for (NSString* metaDef in metasArray) {
        NSDictionary* kvs = [self metaKVsFromString:metaDef];
        NSString* category = kvs[@K_Cate];
        ObjcExt* ext = [[ext_class alloc] initWithCategory:category kvs:kvs name:objcName associatedClass:associatedClass];
        [exts addObject:ext];
    }
    return [exts copy];
}

- (NSString*)description
{
    return [NSString stringWithFormat:@"<%@ : %p>, cls_ext:%@, prop_ext:%@, sel_ext:%@", NSStringFromClass(self.cls), self, __prettyArray(_clsExts), __prettyDict(_propExts), __prettyDict(_selExts)];
}

- (void)print
{
    NSMutableArray* array = [NSMutableArray array];
    [self addNodeDescriptionToArray:array depth:0];
    NSLog(@"\n%@", [array componentsJoinedByString:@"\n"]);
}

- (void)addNodeDescriptionToArray:(NSMutableArray*)array depth:(NSInteger)depth
{
    NSString* prefix = @" ";
    for (int i = 0; i < depth; i++) {
        prefix = [prefix stringByAppendingString:@"   | "];
    }
    [array addObject:[prefix stringByAppendingString:self.description]];
    for (ObjcClassNode* sub in self.subNodes) {
        [sub addNodeDescriptionToArray:array depth:depth+1];
    }
}

@end

@implementation ExtDB

+ (NSString*)metaJsonFilePath
{
    return [[NSBundle mainBundle] pathForResource:@"meta" ofType:@"json" inDirectory:@"objc_ext"];
}

+ (NSString*)metas
{
    return [NSString stringWithContentsOfFile:[self metaJsonFilePath] encoding:NSUTF8StringEncoding error:nil];
}

+ (NSDictionary*)metaDictionary
{
    static NSDictionary* dict;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSData* data = [NSData dataWithContentsOfFile:[self metaJsonFilePath]];
        dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    });
    return dict;
}

+ (NSDictionary*)_classNodesDictionary
{
    static NSDictionary* dict;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSDictionary* metaDict = [self metaDictionary];
        NSMutableDictionary* nodeDict = [NSMutableDictionary dictionary];
        [metaDict enumerateKeysAndObjectsUsingBlock:^(NSString* clsName, NSDictionary*  metas, BOOL * _Nonnull stop) {
            ObjcClassNode* node = [[ObjcClassNode alloc] initWithMetaDefines:metas];
            node.cls = NSClassFromString(clsName);
            nodeDict[clsName] = node;
        }];
        dict = [nodeDict copy];
    });
    return dict;
}

+ (NSDictionary*)classNodesDictionary
{
    NSDictionary* result = [self _classNodesDictionary];
    [self classTree];
    return result;
}

+ (void)buildClassTree:(NSDictionary*)nodeDict atRoot:(ObjcClassNode*)root
{
    NSArray* allNodes = nodeDict.allValues;
    for (ObjcClassNode* node in allNodes) {
        Class super_class = class_getSuperclass(node.cls);
        BOOL inserted = NO;
        while (super_class) {
            NSString* className = NSStringFromClass(super_class);
            ObjcClassNode* super_node = nodeDict[className];
            if (super_node) {
                [super_node addSubNode:node];
                inserted = YES;
                break;
            }
            super_class = class_getSuperclass(super_class);
        }
        
        if (!inserted) {
            [root addSubNode:node];
        }
    }
    
    [root expandRecursively];
}

+ (ObjcClassNode*)classTree
{
    static ObjcClassNode* root;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        root = [[ObjcClassNode alloc] init];
        [self buildClassTree:[self _classNodesDictionary] atRoot:root];
    });
    return root;
}

#pragma mark - class ext finding
+ (NSArray<Class>*)classes_has_ext
{
    return [self classNodesDictionary].allKeys;
}

+ (NSArray<Class>*)classes_with_category:(NSString*)category
{
    static NSDictionary* classesByCategory;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSMutableDictionary* temp = [NSMutableDictionary dictionary];
        for (ObjcClassNode* node in [self classNodesDictionary].allValues) {
            NSArray* clsExts = node.clsExts;
            for (ClassExt* clsExt in clsExts) {
                NSString* cate = clsExt.category;
                NSMutableArray* array = temp[cate];
                if (!array) {
                    array = [NSMutableArray array];
                    temp[cate] = array;
                }
                [array addObject:node.cls];
            }
        }
        classesByCategory = [temp copy];
    });
    
    return classesByCategory[category];
}

+ (NSArray<ClassExt*>*)ext_of_class:(Class)cls
{
    return [[[self classNodesDictionary] objectForKey:NSStringFromClass(cls)] clsExts];
}

+ (ClassExt*)distant_ext_of_class:(Class)cls
{
    return [self ext_of_class:cls].firstObject;
}

#pragma mark - prop ext finding
+ (NSArray<PropertyExt*>*)prop_ext_of_class:(Class)cls
{
    static NSDictionary* propsByCls;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSMutableDictionary* temp = [NSMutableDictionary dictionary];
        for (ObjcClassNode* node in [self classNodesDictionary].allValues) {
            NSString* clsName = NSStringFromClass(node.cls);
            NSMutableArray* array = temp[clsName];
            if (!array) {
                array = [NSMutableArray array];
                temp[clsName] = array;
            }
            for (NSArray<PropertyExt *> * obj in node.propExts.allValues) {
                [array addObjectsFromArray:obj];
            }
        }
        propsByCls = [temp copy];
    });
    
    return propsByCls[NSStringFromClass(cls)];
}
+ (NSArray<PropertyExt*>*)prop_ext_of_class:(Class)cls category:(NSString*)catgory
{
    return (id)[self fileterExtArray:[self prop_ext_of_class:cls] matches:@{@K_Cate:catgory}];
}
+ (NSArray<PropertyExt*>*)prop_ext_of_class:(Class)cls prop_name:(const char*)prop_name
{
    ObjcClassNode* node = [[self classNodesDictionary] objectForKey:NSStringFromClass(cls)];
    return [node.propExts objectForKey:[NSString stringWithUTF8String:prop_name]];
}

#pragma mark - selector ext finding
+ (NSArray<SelectorExt*>*)sel_ext_of_class:(Class)cls
{
    ObjcClassNode* node = [[self classNodesDictionary] objectForKey:NSStringFromClass(cls)];
    NSMutableArray* array = [NSMutableArray array];
    [node.selExts enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, NSArray<SelectorExt *> * _Nonnull obj, BOOL * _Nonnull stop) {
        [array addObjectsFromArray:obj];
    }];
    return array;
}
+ (NSArray<SelectorExt*>*)sel_ext_of_class:(Class)cls category:(NSString*)catgory
{
    return (id)[self fileterExtArray:[self sel_ext_of_class:cls] matches:@{@K_Cate:catgory}];
}
+ (NSArray<SelectorExt*>*)sel_ext_of_class:(Class)cls sel:(SEL)sel
{
    ObjcClassNode* node = [[self classNodesDictionary] objectForKey:NSStringFromClass(cls)];
    return [node.selExts objectForKey:NSStringFromSelector(sel)];
}
+ (SelectorExt*)distance_sel_ext_of_class:(Class)cls sel:(SEL)sel
{
    return [[self sel_ext_of_class:cls sel:sel] firstObject];
}

+ (NSDictionary<NSString*, NSArray<ObjcExt*>* >*)indexExtArray:(NSArray<ObjcExt*>*)extArray
{
    NSMutableDictionary* dict = [NSMutableDictionary dictionary];
    for (ObjcExt* ext in extArray) {
        NSString* objc_name = ext.objc_name;
        NSMutableArray* array = dict[objc_name];
        if (!array) {
            array = [NSMutableArray array];
            dict[objc_name]=array;
        }
        [array addObject:ext];
    }
    return dict;
}

+ (NSArray<ObjcExt*>*)fileterExtArray:(NSArray<ObjcExt*>*)extArray matches:(NSDictionary*)matches
{
    return [extArray filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(ObjcExt* evaluatedObject, NSDictionary<NSString *,id> * _Nullable bindings) {
        for (NSString* m_k in matches.allKeys) {
            NSString* m_v = matches[m_k];
            if (![m_v isEqualToString:[evaluatedObject.kvs objectForKey:m_k]]) {
                return NO;
            }
        }
        return YES;
    }]];
}

@end

