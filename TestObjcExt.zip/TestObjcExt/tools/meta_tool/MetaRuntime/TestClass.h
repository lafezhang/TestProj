//
//  TestClass.h
//  QQLiveChild
//
//  Created by zhang on 2017/3/27.
//  Copyright © 2017年 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestClass : NSObject

@end
