//
//  _ObjcExt_Privite.h
//  QQLiveChild
//
//  Created by zhang on 2017/3/27.
//  Copyright © 2017年 tencent. All rights reserved.
//

#ifndef _ObjcExt_Privite_h
#define _ObjcExt_Privite_h

@interface ObjcExt (Priv)

- (id)initWithCategory:(NSString*)category kvs:(NSDictionary*)kvs name:(NSString*)name associatedClass:(Class)associatedClass;

@property (nonatomic, readonly) NSString* objc_name;
@property (nonatomic, readonly) Class associatedClass;
@end

#endif /* _ObjcExt_Privite_h */
