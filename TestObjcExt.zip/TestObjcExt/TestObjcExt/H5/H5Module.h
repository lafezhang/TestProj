//
//  H5Module.h
//  TestObjcExt
//
//  Created by zhang on 2017/12/28.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MetaRuntime.h"

#define H5ModuleIdentifier "h5"
#define K_ModuleName "n"
#define K_APIName "n"

#define Module(name) Meta_Ext_Cate(H5ModuleIdentifier, K_ModuleName, name)
#define API(name) Meta_Ext_Cate(H5ModuleIdentifier, K_APIName, name)

@interface H5Module : NSObject

@end


// 每当添加一个新的H5模块时，只需要新添加一个类即可
Module("User")
@interface H5UserModule : NSObject

- (void)login API("UserLogIn");

@end

Module("Pay")
@interface H5PayModule : NSObject

- (void)foo API("foo");

@end
