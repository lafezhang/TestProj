//
//  H5Module.m
//  TestObjcExt
//
//  Created by zhang on 2017/12/28.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import "H5Module.h"

@implementation H5Module

@end

@implementation H5UserModule

- (void)login
{
    
}
@end

@implementation H5PayModule

- (void)foo
{
    
}
@end
