//
//  H5ModuleManager.m
//  TestObjcExt
//
//  Created by zhang on 2017/12/28.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import "H5ModuleManager.h"
#import "H5Module.h"
#import "ExtDB.h"

@implementation H5ModuleManager

- (void)loadH5Module
{
    NSArray* allH5ModuleClasses = [ExtDB classes_with_category:@H5ModuleIdentifier];
    for (Class cls in allH5ModuleClasses) {
        id provider = [cls new];
        NSArray<SelectorExt*>* sel_exts = [ExtDB sel_ext_of_class:cls category:@H5ModuleIdentifier];
        for (SelectorExt* sel_ext in sel_exts) {
            NSString* api_name = sel_ext.kvs[@K_APIName];
            NSLog(@"H5Module:%@, exported API:%@", cls, api_name);
        }
    }
}

@end
