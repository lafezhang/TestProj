//
//  JsonObject.h
//  TestObjcExt
//
//  Created by zhang on 2017/12/28.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// 不依赖任何外部文件
@interface JsonObject : NSObject
/*
 {
 "json_color":"#ff0000",
 "user_name":"hahaha",
 "age":1
 }
 */

// 此代码展示了注解的核心机制，就是使用__attribute__ (annotate)来对property selector class进行标记，可以进行任意的标记，
// 然后你在运行时对这些标记的含义进行自定义处理
// 一般会把这种标记定义成宏，来方便书写，可参考H5Module.h
@property (nonatomic) UIColor* color __attribute__((annotate("metaExt_?__cate__=xxx&key=color&type=color&jajaj=sfsaf")));
@property (nonatomic) NSString* userName __attribute__((annotate("metaExt_?__cate__=xxx&key=user_name")));
@property (nonatomic) NSInteger age __attribute__((annotate("metaExt_?__cate__=xxx&key=age")));

@end

