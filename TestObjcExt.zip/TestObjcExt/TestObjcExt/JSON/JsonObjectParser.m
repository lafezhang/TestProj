//
//  JsonObjectParser.m
//  TestObjcExt
//
//  Created by zhang on 2017/12/28.
//  Copyright © 2017年 zhang. All rights reserved.
//

#import "JsonObjectParser.h"
#import "JsonObject.h"
#import "MetaRuntime.h"
#import "ExtDB.h"

@implementation JsonObjectParser

- (void)test
{
    NSArray<PropertyExt*>* propertyExt = [ExtDB prop_ext_of_class:JsonObject.class category:@"xxx"];
    for (PropertyExt* ext in propertyExt) {
        NSLog(@"this class has property:%@, and it will match json key:%@", ext.propertyAsString, ext.kvs[@"key"]);
        
        if ([ext.kvs[@"type"] isEqualToString:@"color"]) {
            // 这是一个color类型，需要转换到UIColor
            NSLog(@"get a color type property!");
        }
    }
}
@end
